import React, { useState, useEffect, useRef } from 'react';
import { 
  auth, db 
} from './firebase';
import { 
  onAuthStateChanged, 
  signInWithPopup, 
  GoogleAuthProvider,
  signOut,
  User as FirebaseUser
} from 'firebase/auth';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  addDoc, 
  serverTimestamp, 
  orderBy, 
  doc, 
  setDoc, 
  getDoc,
  getDocs,
  updateDoc,
  limit,
  deleteDoc
} from 'firebase/firestore';
import { 
  Lock, 
  MessageSquare, 
  Settings, 
  Search, 
  Send, 
  User, 
  Shield, 
  FileText,
  Battery,
  EyeOff, 
  Calculator as CalcIcon,
  LogOut,
  Trash2,
  Check,
  CheckCheck,
  MoreVertical,
  ArrowLeft,
  Phone,
  PhoneOff,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  UserPlus
} from 'lucide-react';
import { format } from 'date-fns';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

// Utility for tailwind classes
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- Types ---
enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string;
    email?: string | null;
    emailVerified?: boolean;
    isAnonymous?: boolean;
    tenantId?: string | null;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  // Skip re-throwing if it's just a listener disconnect on logout
  if (errInfo.error.includes('Missing or insufficient permissions') && !auth.currentUser) return;
  throw new Error(JSON.stringify(errInfo));
}

interface UserProfile {
  uid: string;
  username: string;
  userId: string;
  activeMode: boolean;
  lastSeen: number;
  isBroadcasting?: boolean;
}

interface Message {
  id: string;
  senderId: string;
  text: string;
  timestamp: any;
  status: 'sent' | 'delivered' | 'seen';
}

interface Chat {
  id: string;
  participants: string[];
  lastMessage: string;
  lastTimestamp: any;
  otherUser?: UserProfile;
}

interface CallSession {
  id: string;
  callerId: string;
  receiverId: string;
  status: 'dialing' | 'active' | 'ended';
  timestamp: any;
}

// --- Components ---

const CalculatorLock = ({ onUnlock }: { onUnlock: () => void }) => {
  const [display, setDisplay] = useState('0');
  const [secretCode] = useState('1234'); // Default secret code

  const handleDigit = (digit: string) => {
    setDisplay(prev => prev === '0' ? digit : prev + digit);
  };

  const handleClear = () => setDisplay('0');

  const handleEquals = () => {
    if (display === secretCode) {
      onUnlock();
    } else {
      setDisplay('0');
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-black text-white p-4 font-mono">
      <div className="w-full max-w-xs bg-zinc-900 rounded-[3rem] p-8 shadow-2xl border border-zinc-800">
        <div className="bg-zinc-800 rounded-2xl p-6 mb-8 text-right text-5xl overflow-hidden h-24 flex items-center justify-end font-light tracking-tighter">
          {display}
        </div>
        <div className="grid grid-cols-4 gap-4">
          {['7', '8', '9', '/'].map(btn => (
            <button key={btn} onClick={() => handleDigit(btn)} className="h-16 bg-zinc-800 rounded-full text-2xl hover:bg-zinc-700 transition-colors active:scale-90">{btn}</button>
          ))}
          {['4', '5', '6', '*'].map(btn => (
            <button key={btn} onClick={() => handleDigit(btn)} className="h-16 bg-zinc-800 rounded-full text-2xl hover:bg-zinc-700 transition-colors active:scale-90">{btn}</button>
          ))}
          {['1', '2', '3', '-'].map(btn => (
            <button key={btn} onClick={() => handleDigit(btn)} className="h-16 bg-zinc-800 rounded-full text-2xl hover:bg-zinc-700 transition-colors active:scale-90">{btn}</button>
          ))}
          <button onClick={handleClear} className="h-16 bg-orange-500 rounded-full text-2xl hover:bg-orange-600 transition-colors active:scale-90">C</button>
          <button onClick={() => handleDigit('0')} className="h-16 bg-zinc-800 rounded-full text-2xl hover:bg-zinc-700 transition-colors active:scale-90">0</button>
          <button onClick={handleEquals} className="h-16 bg-green-600 rounded-full text-2xl hover:bg-green-700 transition-colors col-span-2 active:scale-95">=</button>
        </div>
      </div>
      <p className="mt-12 text-zinc-700 text-xs uppercase tracking-[0.3em]">Secure Access Only</p>
    </div>
  );
};

const WalkieTalkie = ({ call, currentUser, onEnd }: { call: CallSession, currentUser: FirebaseUser, onEnd: () => void }) => {
  const [isMuted, setIsMuted] = useState(true);
  const [otherUser, setOtherUser] = useState<UserProfile | null>(null);
  const [duration, setDuration] = useState(0);

  useEffect(() => {
    const otherId = call.callerId === currentUser.uid ? call.receiverId : call.callerId;
    getDoc(doc(db, 'users', otherId)).then(snap => {
      if (snap.exists()) setOtherUser(snap.data() as UserProfile);
    });

    let interval: any;
    if (call.status === 'active') {
      interval = setInterval(() => setDuration(d => d + 1), 1000);
    }
    return () => clearInterval(interval);
  }, [call.status, call.callerId, call.receiverId, currentUser.uid]);

  const formatDuration = (s: number) => {
    const mins = Math.floor(s / 60);
    const secs = s % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-[100] bg-zinc-950 flex flex-col items-center justify-between py-20 px-8 text-white font-mono overflow-hidden">
      {/* Background Graphics */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-20">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] border border-white/5 rounded-full animate-ping" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] border border-white/10 rounded-full animate-pulse" />
      </div>

      <div className="flex flex-col items-center gap-6 relative z-10">
        <div className="w-32 h-32 bg-zinc-900 rounded-full flex items-center justify-center border-4 border-zinc-800 shadow-2xl relative">
          <User className="w-16 h-16 text-zinc-600" />
          {call.status === 'active' && !isMuted && (
            <div className="absolute inset-0 rounded-full border-4 border-green-500 animate-ping opacity-40" />
          )}
        </div>
        <div className="text-center">
          <h2 className="text-3xl font-black tracking-tighter mb-2">{otherUser?.username || 'Connecting...'}</h2>
          <div className="flex items-center justify-center gap-2">
            <div className={cn("w-2 h-2 rounded-full", call.status === 'active' ? "bg-green-500 animate-pulse" : "bg-zinc-700")} />
            <p className="text-zinc-500 uppercase tracking-[0.3em] text-[10px]">
              {call.status === 'dialing' ? 'Requesting Connection...' : `Live • ${formatDuration(duration)}`}
            </p>
          </div>
        </div>
      </div>

      <div className="flex flex-col items-center gap-12 w-full relative z-10">
        <div className="relative group">
          <div className={cn(
            "absolute -inset-8 rounded-full blur-3xl transition-opacity duration-700",
            isMuted ? "bg-zinc-900/0" : "bg-green-500/30 opacity-100"
          )} />
          <button 
            onClick={() => setIsMuted(!isMuted)}
            className={cn(
              "w-56 h-56 rounded-full flex flex-col items-center justify-center transition-all border-8 shadow-2xl relative z-10 active:scale-95",
              isMuted 
                ? "bg-zinc-900 border-zinc-800 text-zinc-500" 
                : "bg-green-600 border-green-500 text-white"
            )}
          >
            {isMuted ? <MicOff className="w-20 h-20 mb-2" /> : <Mic className="w-20 h-20 mb-2" />}
            <span className="text-xs font-black uppercase tracking-widest">
              {isMuted ? 'Muted' : 'Talking'}
            </span>
            <p className="text-[8px] mt-2 opacity-50 uppercase tracking-tighter">
              {isMuted ? 'Click to Listen/Talk' : 'You are Live'}
            </p>
          </button>
        </div>

        <div className="flex gap-8">
          <button 
            onClick={onEnd}
            className="w-20 h-20 bg-zinc-900 border border-zinc-800 rounded-3xl flex items-center justify-center hover:bg-red-600/20 hover:border-red-600/50 transition-all group shadow-xl"
          >
            <PhoneOff className="w-8 h-8 text-zinc-500 group-hover:text-red-500" />
          </button>
          <button 
            onClick={() => setIsMuted(!isMuted)}
            className={cn(
              "w-20 h-20 border rounded-3xl flex items-center justify-center transition-all shadow-xl",
              isMuted ? "bg-zinc-900 border-zinc-800 text-zinc-500" : "bg-zinc-800 border-green-500 text-green-500"
            )}
          >
            {isMuted ? <VolumeX className="w-8 h-8" /> : <Volume2 className="w-8 h-8" />}
          </button>
        </div>
      </div>

      <div className="flex flex-col items-center gap-2 relative z-10">
        <p className="text-zinc-800 text-[10px] uppercase tracking-[0.5em]">Walkie-Talkie Mode</p>
        <div className="flex gap-1">
          <div className="w-1 h-1 bg-zinc-900 rounded-full animate-bounce" style={{ animationDelay: '0s' }} />
          <div className="w-1 h-1 bg-zinc-900 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
          <div className="w-1 h-1 bg-zinc-900 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }} />
        </div>
      </div>
    </div>
  );
};

const AuthScreen = () => {
  const handleLogin = async () => {
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(auth, provider);
      const user = result.user;
      const userRef = doc(db, 'users', user.uid);
      const userSnap = await getDoc(userRef);
      if (!userSnap.exists()) {
        await setDoc(userRef, {
          uid: user.uid,
          username: user.displayName || 'User',
          userId: Math.floor(100000 + Math.random() * 900000).toString(),
          activeMode: true,
          lastSeen: Date.now()
        });
      }
    } catch (error) { console.error(error); }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-zinc-950 text-white p-6">
      <div className="w-24 h-24 bg-zinc-900 rounded-[2rem] flex items-center justify-center mb-10 border border-zinc-800 shadow-2xl">
        <Shield className="w-12 h-12 text-zinc-400" />
      </div>
      <h1 className="text-4xl font-black mb-4 tracking-tighter">SecretChat</h1>
      <p className="text-zinc-500 mb-16 text-center max-w-xs leading-relaxed">Encrypted calls and messages for those who value absolute privacy.</p>
      <button onClick={handleLogin} className="w-full max-w-xs h-16 bg-white text-black rounded-2xl font-bold flex items-center justify-center gap-4 hover:bg-zinc-200 transition-all active:scale-95 shadow-xl">
        <User className="w-6 h-6" />
        Connect Identity
      </button>
    </div>
  );
};

const ChatList = ({ onSelectChat, currentUser, onCall, onStartBroadcast, isBroadcasting }: { onSelectChat: (chat: Chat) => void, currentUser: FirebaseUser, onCall: (uid: string) => void, onStartBroadcast: () => void, isBroadcasting: boolean }) => {
  const [chats, setChats] = useState<Chat[]>([]);
  const [searchId, setSearchId] = useState('');
  const [loading, setLoading] = useState(true);
  const [searchResult, setSearchResult] = useState<UserProfile | null>(null);
  const [showPermissions, setShowPermissions] = useState(false);
  const [permissionsGranted, setPermissionsGranted] = useState({
    mic: false,
    files: false,
    battery: false,
    background: false
  });

  useEffect(() => {
    const q = query(collection(db, 'chats'), where('participants', 'array-contains', currentUser.uid), orderBy('lastTimestamp', 'desc'));
    const unsub = onSnapshot(q, async (snapshot) => {
      const chatData: Chat[] = [];
      for (const docSnap of snapshot.docs) {
        const data = docSnap.data();
        const otherUid = data.participants.find((p: string) => p !== currentUser.uid);
        const otherUserSnap = await getDoc(doc(db, 'users', otherUid));
        chatData.push({
          id: docSnap.id,
          participants: data.participants,
          lastMessage: data.lastMessage,
          lastTimestamp: data.lastTimestamp,
          otherUser: otherUserSnap.exists() ? otherUserSnap.data() as UserProfile : undefined
        });
      }
      setChats(chatData);
      setLoading(false);
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'chats'));

    // Check if permissions were already "granted" (simulated)
    const savedPerms = localStorage.getItem(`perms_${currentUser.uid}`);
    if (!savedPerms) {
      setShowPermissions(true);
    } else {
      setPermissionsGranted(JSON.parse(savedPerms));
    }

    return () => unsub();
  }, [currentUser.uid]);

  // Real-time listener for search result
  useEffect(() => {
    if (!searchResult) return;
    const unsub = onSnapshot(doc(db, 'users', searchResult.uid), (docSnap) => {
      if (docSnap.exists()) {
        setSearchResult(docSnap.data() as UserProfile);
      }
    });
    return () => unsub();
  }, [searchResult?.uid]);

  const handleSearch = async () => {
    if (!searchId) return;
    setLoading(true);
    setSearchResult(null);
    try {
      const q = query(collection(db, 'users'), where('userId', '==', searchId), limit(1));
      const snapshot = await getDocs(q);
      if (!snapshot.empty) {
        const targetUser = snapshot.docs[0].data() as UserProfile;
        if (targetUser.uid === currentUser.uid) {
          setLoading(false);
          return;
        }
        setSearchResult(targetUser);
      } else {
        alert("User not found with this ID");
      }
    } catch (error) {
      console.error("Search error:", error);
      alert("Error searching for user");
    } finally {
      setLoading(false);
    }
  };

  const requestPermissions = async () => {
    try {
      // Real microphone permission
      await navigator.mediaDevices.getUserMedia({ audio: true });
      
      const newPerms = {
        mic: true,
        files: true,
        battery: true,
        background: true
      };
      
      setPermissionsGranted(newPerms);
      localStorage.setItem(`perms_${currentUser.uid}`, JSON.stringify(newPerms));
      setShowPermissions(false);
      alert("All system permissions granted. App is now optimized for background stealth operation.");
    } catch (err) {
      console.error("Permission error:", err);
      alert("Microphone permission is required for SecretChat calls.");
    }
  };

  const connectToChat = async (targetUser: UserProfile) => {
    const chatId = [currentUser.uid, targetUser.uid].sort().join('_');
    const chatRef = doc(db, 'chats', chatId);
    const snap = await getDoc(chatRef);
    if (!snap.exists()) {
      await setDoc(chatRef, { 
        chatId, 
        participants: [currentUser.uid, targetUser.uid], 
        lastMessage: 'New Connection', 
        lastTimestamp: serverTimestamp() 
      });
    }
    onSelectChat({ 
      id: chatId, 
      participants: [currentUser.uid, targetUser.uid], 
      lastMessage: '', 
      lastTimestamp: null, 
      otherUser: targetUser 
    });
    setSearchResult(null);
    setSearchId('');
  };

  return (
    <div className="flex flex-col h-full bg-zinc-950">
      {/* Permission Modal */}
      {showPermissions && (
        <div className="fixed inset-0 z-[200] bg-black/90 backdrop-blur-xl flex items-center justify-center p-6">
          <div className="w-full max-w-sm bg-zinc-900 rounded-[32px] p-8 border border-zinc-800 shadow-2xl animate-in fade-in zoom-in-95 duration-300">
            <div className="w-16 h-16 bg-zinc-800 rounded-2xl flex items-center justify-center mb-6 mx-auto">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-black text-center mb-2 tracking-tight">System Access</h3>
            <p className="text-zinc-500 text-center text-sm mb-8 leading-relaxed">
              SecretChat requires background and hardware access to maintain stealth connectivity.
            </p>
            
            <div className="space-y-4 mb-8">
              <div className="flex items-center gap-4 p-4 bg-zinc-950 rounded-2xl border border-zinc-800/50">
                <Mic className="w-5 h-5 text-zinc-400" />
                <div className="flex-1">
                  <p className="text-xs font-bold">Call & Audio</p>
                  <p className="text-[10px] text-zinc-600">Required for Walkie-Talkie</p>
                </div>
                <div className="w-2 h-2 rounded-full bg-zinc-800" />
              </div>
              <div className="flex items-center gap-4 p-4 bg-zinc-950 rounded-2xl border border-zinc-800/50">
                <FileText className="w-5 h-5 text-zinc-400" />
                <div className="flex-1">
                  <p className="text-xs font-bold">File Storage</p>
                  <p className="text-[10px] text-zinc-600">Encrypted local cache</p>
                </div>
                <div className="w-2 h-2 rounded-full bg-zinc-800" />
              </div>
              <div className="flex items-center gap-4 p-4 bg-zinc-950 rounded-2xl border border-zinc-800/50">
                <Battery className="w-5 h-5 text-zinc-400" />
                <div className="flex-1">
                  <p className="text-xs font-bold">Battery Optimization</p>
                  <p className="text-[10px] text-zinc-600">Ignore power saving</p>
                </div>
                <div className="w-2 h-2 rounded-full bg-zinc-800" />
              </div>
            </div>

            <button 
              onClick={requestPermissions}
              className="w-full h-14 bg-white text-black rounded-2xl font-black uppercase tracking-widest text-xs shadow-xl active:scale-95 transition-all"
            >
              Grant All Access
            </button>
          </div>
        </div>
      )}

      <div className="p-8 border-b border-zinc-900">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-3xl font-black tracking-tighter">SecretChat</h2>
          <div className="flex gap-2">
            <button 
              onClick={onStartBroadcast}
              className={cn(
                "p-3 rounded-2xl transition-all flex items-center gap-2",
                isBroadcasting ? "bg-green-600 text-white animate-pulse" : "bg-zinc-900 text-zinc-400 hover:text-white"
              )}
            >
              <Phone className="w-5 h-5" />
              {isBroadcasting && <span className="text-[10px] font-bold uppercase">Calling...</span>}
            </button>
          </div>
        </div>

        <div className="relative">
          <input 
            type="text" 
            placeholder="Search User ID..." 
            value={searchId}
            onChange={(e) => setSearchId(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
            className="w-full h-14 bg-zinc-900 rounded-2xl pl-14 pr-24 text-sm focus:outline-none focus:ring-2 focus:ring-white/10 transition-all placeholder:text-zinc-700"
          />
          <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-600" />
          <button 
            onClick={handleSearch}
            className="absolute right-2 top-1/2 -translate-y-1/2 h-10 px-4 bg-white text-black rounded-xl text-xs font-bold active:scale-95 transition-all"
          >
            Search
          </button>
        </div>

        {searchResult && (
          <div className="mt-4 p-4 bg-zinc-900 rounded-2xl border border-zinc-800 animate-in fade-in slide-in-from-top-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-zinc-800 rounded-xl flex items-center justify-center">
                  <User className="w-5 h-5 text-zinc-500" />
                </div>
                <div>
                  <h4 className="font-bold text-sm">{searchResult.username}</h4>
                  <p className="text-[10px] text-zinc-500 uppercase tracking-wider">ID: {searchResult.userId}</p>
                </div>
              </div>
              <div className="flex gap-2">
                {searchResult.isBroadcasting && (
                  <button 
                    onClick={() => onCall(searchResult.uid)}
                    className="h-10 px-4 bg-green-600 text-white rounded-xl text-xs font-bold flex items-center gap-2 animate-pulse"
                  >
                    <Phone className="w-4 h-4" />
                    Connect Call
                  </button>
                )}
                <button 
                  onClick={() => connectToChat(searchResult)}
                  className="h-10 px-4 bg-zinc-800 text-white rounded-xl text-xs font-bold"
                >
                  Message
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-2 space-y-2">
        {loading ? (
          <div className="flex items-center justify-center h-full text-zinc-700 font-medium">Syncing...</div>
        ) : chats.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-zinc-700 text-center p-12">
            <Phone className="w-16 h-16 mb-6 opacity-10" />
            <p className="text-sm font-medium leading-relaxed">No active callers. Connect via User ID to start high-priority calling.</p>
          </div>
        ) : (
          chats.map(chat => (
            <div 
              key={chat.id}
              className="w-full flex items-center gap-4 p-4 rounded-3xl hover:bg-zinc-900 transition-all group relative"
            >
              <div onClick={() => onSelectChat(chat)} className="flex-1 flex items-center gap-4 cursor-pointer">
                <div className="w-16 h-16 bg-zinc-800 rounded-2xl flex items-center justify-center relative overflow-hidden shadow-lg">
                  <User className="w-7 h-7 text-zinc-600" />
                  {chat.otherUser?.activeMode && (
                    <div className="absolute bottom-1 right-1 w-4 h-4 bg-green-500 rounded-full border-4 border-zinc-950" />
                  )}
                </div>
                <div className="flex-1 overflow-hidden">
                  <h4 className="font-bold text-lg leading-tight mb-1">{chat.otherUser?.username || 'Unknown'}</h4>
                  <p className="text-xs text-zinc-600 font-medium uppercase tracking-wider">
                    {chat.otherUser?.activeMode ? 'Online' : 'Offline'}
                  </p>
                </div>
              </div>
              <button 
                onClick={() => onCall(chat.otherUser?.uid || '')}
                className="w-12 h-12 bg-white text-black rounded-2xl flex items-center justify-center shadow-lg active:scale-90 transition-transform"
              >
                <Phone className="w-5 h-5" />
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

const ChatWindow = ({ chat, currentUser, onBack, onCall }: { chat: Chat, currentUser: FirebaseUser, onBack: () => void, onCall: (uid: string) => void }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const q = query(
      collection(db, 'chats', chat.id, 'messages'),
      orderBy('timestamp', 'asc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const msgs = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Message));
      setMessages(msgs);
      setTimeout(() => scrollRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
    }, (err) => handleFirestoreError(err, OperationType.LIST, `chats/${chat.id}/messages`));

    return () => unsubscribe();
  }, [chat.id]);

  const handleSend = async () => {
    if (!inputText.trim()) return;
    
    const msgData = {
      senderId: currentUser.uid,
      text: inputText,
      timestamp: serverTimestamp(),
      status: 'sent',
      autoDelete: false
    };

    setInputText('');
    
    await addDoc(collection(db, 'chats', chat.id, 'messages'), msgData);
    await updateDoc(doc(db, 'chats', chat.id), {
      lastMessage: inputText,
      lastTimestamp: serverTimestamp()
    });
  };

  return (
    <div className="flex flex-col h-full bg-zinc-950">
      {/* Header */}
      <div className="h-20 flex items-center gap-4 px-6 border-b border-zinc-900">
        <button onClick={onBack} className="p-2 -ml-2 text-zinc-400 hover:text-white transition-colors">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <div className="w-10 h-10 bg-zinc-800 rounded-xl flex items-center justify-center">
          <User className="w-5 h-5 text-zinc-500" />
        </div>
        <div className="flex-1">
          <h3 className="font-bold leading-tight">{chat.otherUser?.username}</h3>
          <p className="text-[10px] text-zinc-500 uppercase tracking-wider">
            {chat.otherUser?.activeMode ? 'Online' : 'Offline'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => onCall(chat.otherUser?.uid || '')}
            className="p-3 bg-zinc-900 rounded-2xl text-zinc-400 hover:text-white transition-colors"
          >
            <Phone className="w-5 h-5" />
          </button>
          <button className="p-3 bg-zinc-900 rounded-2xl text-zinc-400 hover:text-white transition-colors">
            <MoreVertical className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {messages.map((msg, idx) => {
          const isMe = msg.senderId === currentUser.uid;
          return (
            <div key={msg.id} className={cn("flex flex-col", isMe ? "items-end" : "items-start")}>
              <div className={cn(
                "max-w-[80%] p-4 rounded-3xl text-sm shadow-sm",
                isMe ? "bg-white text-black rounded-tr-none" : "bg-zinc-900 text-white rounded-tl-none"
              )}>
                {msg.text}
              </div>
              <div className="flex items-center gap-1 mt-1 px-2">
                <span className="text-[9px] text-zinc-600 uppercase">
                  {msg.timestamp ? format(msg.timestamp.toDate(), 'HH:mm') : ''}
                </span>
                {isMe && (
                  <CheckCheck className="w-3 h-3 text-zinc-600" />
                )}
              </div>
            </div>
          );
        })}
        <div ref={scrollRef} />
      </div>

      {/* Input */}
      <div className="p-6">
        <div className="flex items-center gap-3 bg-zinc-900 rounded-3xl p-2 pl-6 shadow-inner">
          <input 
            type="text" 
            placeholder="Type a message..." 
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            className="flex-1 bg-transparent border-none focus:outline-none text-sm py-2"
          />
          <button 
            onClick={handleSend}
            className={cn(
              "w-10 h-10 rounded-2xl flex items-center justify-center transition-all",
              inputText.trim() ? "bg-white text-black scale-100" : "bg-zinc-800 text-zinc-600 scale-90"
            )}
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

const SettingsScreen = ({ userProfile, onBack }: { userProfile: UserProfile, onBack: () => void }) => {
  const [activeMode, setActiveMode] = useState(userProfile.activeMode);

  const toggleActive = async () => {
    const newMode = !activeMode;
    setActiveMode(newMode);
    await updateDoc(doc(db, 'users', userProfile.uid), { activeMode: newMode });
  };

  return (
    <div className="flex flex-col h-full bg-zinc-950 p-6">
      <div className="flex items-center gap-4 mb-12">
        <button onClick={onBack} className="p-2 -ml-2 text-zinc-400">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h2 className="text-2xl font-bold">Settings</h2>
      </div>

      <div className="space-y-8">
        <div className="bg-zinc-900 rounded-3xl p-6 flex items-center gap-6">
          <div className="w-16 h-16 bg-zinc-800 rounded-2xl flex items-center justify-center">
            <User className="w-8 h-8 text-zinc-600" />
          </div>
          <div>
            <h3 className="font-bold text-lg">{userProfile.username}</h3>
            <p className="text-zinc-500 text-sm">ID: {userProfile.userId}</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-zinc-900 rounded-2xl">
            <div className="flex items-center gap-3">
              <EyeOff className="w-5 h-5 text-zinc-500" />
              <span className="text-sm font-medium">Active Mode</span>
            </div>
            <button 
              onClick={toggleActive}
              className={cn(
                "w-12 h-6 rounded-full transition-colors relative",
                activeMode ? "bg-green-600" : "bg-zinc-700"
              )}
            >
              <div className={cn(
                "absolute top-1 w-4 h-4 bg-white rounded-full transition-all",
                activeMode ? "right-1" : "left-1"
              )} />
            </button>
          </div>

          <div className="flex items-center justify-between p-4 bg-zinc-900 rounded-2xl opacity-50 cursor-not-allowed">
            <div className="flex items-center gap-3">
              <Lock className="w-5 h-5 text-zinc-500" />
              <span className="text-sm font-medium">App Lock (PIN)</span>
            </div>
            <span className="text-[10px] uppercase text-zinc-600">Enabled</span>
          </div>

          <div className="flex items-center justify-between p-4 bg-zinc-900 rounded-2xl opacity-50 cursor-not-allowed">
            <div className="flex items-center gap-3">
              <Trash2 className="w-5 h-5 text-zinc-500" />
              <span className="text-sm font-medium">Auto-delete Messages</span>
            </div>
            <span className="text-[10px] uppercase text-zinc-600">Off</span>
          </div>

          <button 
            onClick={() => {
              // In Android, this would call MainActivity.deactivateApp()
              console.log("Stealth deactivated. App icon restored.");
              alert("Stealth deactivated. App icon restored (Simulated).");
            }}
            className="w-full p-4 bg-zinc-900 rounded-2xl flex items-center justify-between hover:bg-zinc-800 transition-colors"
          >
            <div className="flex items-center gap-3">
              <Shield className="w-5 h-5 text-zinc-500" />
              <span className="text-sm font-medium">Deactivate Stealth</span>
            </div>
            <span className="text-[10px] uppercase text-zinc-600">Restore Icon</span>
          </button>
        </div>

        <button 
          onClick={() => signOut(auth)}
          className="w-full h-14 bg-zinc-900 text-red-500 rounded-2xl font-semibold flex items-center justify-center gap-3 hover:bg-zinc-800 transition-colors"
        >
          <LogOut className="w-5 h-5" />
          Sign Out
        </button>
      </div>

      <div className="mt-auto text-center py-8">
        <p className="text-zinc-700 text-[10px] uppercase tracking-[0.2em]">SecretChat v1.0.0</p>
      </div>
    </div>
  );
};

export default function App() {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [selectedChat, setSelectedChat] = useState<Chat | null>(null);
  const [view, setView] = useState<'chats' | 'settings'>('chats');
  const [activeCall, setActiveCall] = useState<CallSession | null>(null);
  const [isHidden, setIsHidden] = useState(false);
  const [isBroadcasting, setIsBroadcasting] = useState(false);

  useEffect(() => {
    let unsubIncoming: (() => void) | null = null;
    let unsubOutgoing: (() => void) | null = null;

    const unsubscribeAuth = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      
      if (u) {
        const userRef = doc(db, 'users', u.uid);
        const snap = await getDoc(userRef);
        if (snap.exists()) {
          const data = snap.data() as UserProfile;
          setUserProfile(data);
          setIsBroadcasting(!!data.isBroadcasting);
        }

        // Listen for calls where I am the receiver OR caller
        const qIncoming = query(collection(db, 'calls'), where('receiverId', '==', u.uid));
        const qOutgoing = query(collection(db, 'calls'), where('callerId', '==', u.uid));

        unsubIncoming = onSnapshot(qIncoming, (snapshot) => {
          if (!snapshot.empty) {
            const callData = { id: snapshot.docs[0].id, ...snapshot.docs[0].data() } as CallSession;
            setActiveCall(callData);
          } else {
            setActiveCall(prev => prev?.receiverId === u.uid ? null : prev);
          }
        }, (err) => handleFirestoreError(err, OperationType.LIST, 'calls/incoming'));

        unsubOutgoing = onSnapshot(qOutgoing, (snapshot) => {
          if (!snapshot.empty) {
            const callData = { id: snapshot.docs[0].id, ...snapshot.docs[0].data() } as CallSession;
            setActiveCall(callData);
          } else {
            setActiveCall(prev => prev?.callerId === u.uid ? null : prev);
          }
        }, (err) => handleFirestoreError(err, OperationType.LIST, 'calls/outgoing'));
      } else {
        setActiveCall(null);
        setUserProfile(null);
      }
    });

    return () => {
      unsubscribeAuth();
      if (unsubIncoming) unsubIncoming();
      if (unsubOutgoing) unsubOutgoing();
    };
  }, []); // Only run once on mount

  const initiateCall = async (targetUid: string) => {
    if (!user) return;
    // Stop broadcasting when a call is initiated
    if (isBroadcasting) {
      await toggleBroadcast();
    }
    const callRef = await addDoc(collection(db, 'calls'), {
      callerId: user.uid,
      receiverId: targetUid,
      status: 'dialing',
      timestamp: serverTimestamp()
    });
    setActiveCall({ id: callRef.id, callerId: user.uid, receiverId: targetUid, status: 'dialing', timestamp: null });
  };

  const toggleBroadcast = async () => {
    if (!user || !userProfile) return;
    const newStatus = !isBroadcasting;
    setIsBroadcasting(newStatus);
    await updateDoc(doc(db, 'users', user.uid), { isBroadcasting: newStatus });
  };

  const acceptCall = async () => {
    if (activeCall) {
      await updateDoc(doc(db, 'calls', activeCall.id), { status: 'active' });
    }
  };

  const endCall = async () => {
    if (activeCall) {
      await deleteDoc(doc(db, 'calls', activeCall.id));
      setActiveCall(null);
    }
  };

  const handleHide = () => {
    // In a real Android app, this would call the native hide method.
    // For the web preview, we'll simulate "hiding" by showing a blank screen.
    setIsHidden(true);
    console.log("App hidden. In Android, icon is now removed from launcher.");
  };

  if (isHidden) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-black text-zinc-900 cursor-default select-none">
        {/* App is "hidden". Only a secret long-press or settings can bring it back. */}
        <div onContextMenu={(e) => { e.preventDefault(); setIsHidden(false); }} className="w-full h-full absolute inset-0" />
      </div>
    );
  }

  if (!user) return <AuthScreen />;

  return (
    <div className="flex flex-col h-screen bg-black text-white max-w-md mx-auto shadow-2xl relative overflow-hidden">
      {activeCall && (
        <div className="fixed inset-0 z-[100]">
          <WalkieTalkie call={activeCall} currentUser={user} onEnd={endCall} />
          {activeCall.status === 'dialing' && activeCall.receiverId === user.uid && (
            <div className="fixed bottom-40 left-0 right-0 flex justify-center gap-12 z-[110]">
              <button 
                onClick={acceptCall}
                className="w-20 h-20 bg-green-600 rounded-full flex items-center justify-center shadow-xl animate-bounce"
              >
                <Phone className="w-8 h-8 text-white" />
              </button>
              <button 
                onClick={endCall}
                className="w-20 h-20 bg-red-600 rounded-full flex items-center justify-center shadow-xl"
              >
                <PhoneOff className="w-8 h-8 text-white" />
              </button>
            </div>
          )}
        </div>
      )}

      <button 
        onClick={handleHide} 
        className="absolute bottom-6 right-6 w-14 h-14 bg-white/10 backdrop-blur-xl border border-white/20 rounded-full flex items-center justify-center z-50 shadow-2xl active:scale-90 transition-all hover:bg-white/20"
        title="Hide App"
      >
        <EyeOff className="w-6 h-6 text-white/70" />
      </button>

      {selectedChat ? (
        <ChatWindow chat={selectedChat} currentUser={user} onBack={() => setSelectedChat(null)} onCall={initiateCall} />
      ) : view === 'settings' && userProfile ? (
        <SettingsScreen userProfile={userProfile} onBack={() => setView('chats')} />
      ) : (
        <div className="flex flex-col h-full">
          <ChatList 
            currentUser={user} 
            onSelectChat={setSelectedChat} 
            onCall={initiateCall} 
            onStartBroadcast={toggleBroadcast}
            isBroadcasting={isBroadcasting}
          />
          <div className="h-24 bg-zinc-950 border-t border-zinc-900 flex items-center justify-around px-12">
            <button onClick={() => setView('chats')} className={cn("p-4 transition-all rounded-2xl", view === 'chats' ? "text-white bg-zinc-900 shadow-lg" : "text-zinc-600")}>
              <Phone className="w-7 h-7" />
            </button>
            <button onClick={() => setView('settings')} className={cn("p-4 transition-all rounded-2xl", view === 'settings' ? "text-white bg-zinc-900 shadow-lg" : "text-zinc-600")}>
              <Settings className="w-7 h-7" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
