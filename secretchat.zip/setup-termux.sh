#!/bin/bash

# SecretChat - Termux Setup Script
# This script automates the installation of Node.js and dependencies in Termux.

echo "Updating Termux packages..."
pkg update && pkg upgrade -y

echo "Installing Node.js and Git..."
pkg install nodejs git -y

echo "Installing project dependencies..."
npm install

echo "Building the project..."
npm run build

echo "Setup complete! You can now run the app with: npm run dev"
echo "Access it at: http://localhost:3000"
