# SecretChat - Termux Setup Guide

This app is optimized for running on Android via **Termux**. Follow the steps below to set up and run the app directly on your phone.

## 1. Install Prerequisites in Termux
Open Termux and run the following commands:
```bash
pkg update && pkg upgrade
pkg install nodejs git
```

## 2. Unzip and Navigate to Project
After downloading the ZIP file from AI Studio, unzip it in your Termux home directory:
```bash
unzip project.zip -d secretchat
cd secretchat
```

## 3. Install Dependencies
```bash
npm install
```

## 4. Run the App
To start the development server:
```bash
npm run dev
```
Once it starts, you can access the app in your phone's browser at: `http://localhost:3000`

## 5. Build for Production
To build the app for better performance:
```bash
npm run build
npm run start
```

## 6. (Optional) Build as an Android App (APK)
If you want to turn this into a real Android app, you will need a PC with Android Studio. 
1. Copy the project to your PC.
2. Run: `npx cap add android`
3. Run: `npx cap open android`
4. Build the APK in Android Studio.

---
**Note:** Make sure your `firebase-applet-config.json` is correctly set up with your own Firebase keys if you are running this outside of AI Studio.
