# SecretChat Android Application Source Code

This directory contains the full source code for the Android version of SecretChat.

## Features
- **Hidden Launcher**: App icon can be hidden and opened via dialer (`*#1234#`) or calculator.
- **Foreground Service**: Background message receiving.
- **Firebase Integration**: Real-time messaging and Auth.
- **Privacy**: PIN lock, screenshot blocking, and stealth mode.

## Structure
- `app/src/main/java/com/secretchat/`: Kotlin source code.
- `app/src/main/res/layout/`: XML layouts.
- `app/src/main/AndroidManifest.xml`: App configuration.

## Firebase Setup Guide
1. Go to [Firebase Console](https://console.firebase.google.com/).
2. Create a new project named "SecretChat".
3. Add an Android App:
   - Package name: `com.secretchat`
4. Download `google-services.json` and place it in the `app/` directory of this source code.
5. Enable **Authentication**:
   - Enable "Google" or "Email/Password" providers.
6. Enable **Cloud Firestore**:
   - Create a database in "Production Mode".
   - Copy the rules from the `firestore.rules` file in the root of this project.
7. Enable **Cloud Messaging** (for notifications).

## Step-by-Step Build APK Instructions
1. **Install Android Studio**: Download and install the latest version.
2. **Open Project**: Select "Open" and navigate to this `android/` folder.
3. **Sync Gradle**: Wait for Android Studio to download dependencies and sync.
4. **Configure Firebase**: Ensure `google-services.json` is in the `app/` folder.
5. **Build APK**:
   - Go to `Build` > `Build Bundle(s) / APK(s)` > `Build APK(s)`.
   - Once finished, a notification will appear. Click "locate" to find the `app-debug.apk`.
6. **Install on Phone**:
   - Transfer the APK to your Android device.
   - Enable "Install from Unknown Sources" in settings.
   - Install and open.

## Enabling Hidden Launcher Activity
- By default, the app opens as a **Calculator**.
- To enter the chat:
  - Type `1234` and press `=`.
- To hide the app icon from the launcher:
  - Go to Settings in the app and toggle "Stealth Mode".
  - This uses `PackageManager` to disable the launcher component.
- To open the app when hidden:
  - Open the phone dialer and call `*#1234#`.
  - The `SecretDialReceiver` will intercept this and launch the app.
