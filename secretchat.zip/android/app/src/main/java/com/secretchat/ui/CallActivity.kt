package com.secretchat.ui

import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.secretchat.R

class CallActivity : AppCompatActivity() {
    private var isMuted = false
    private var isSpeaker = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_call)

        val btnMute = findViewById<ImageButton>(R.id.btnMute)
        val btnSpeaker = findViewById<ImageButton>(R.id.btnSpeaker)
        val btnEndCall = findViewById<ImageButton>(R.id.btnEndCall)

        btnMute.setOnClickListener {
            isMuted = !isMuted
            btnMute.setImageResource(if (isMuted) R.drawable.ic_mic_off else R.drawable.ic_mic)
            // Logic to mute audio
        }

        btnSpeaker.setOnClickListener {
            isSpeaker = !isSpeaker
            btnSpeaker.setImageResource(if (isSpeaker) R.drawable.ic_volume_up else R.drawable.ic_volume_down)
            // Logic to toggle speaker
        }

        btnEndCall.setOnClickListener {
            finish()
        }
    }
}
