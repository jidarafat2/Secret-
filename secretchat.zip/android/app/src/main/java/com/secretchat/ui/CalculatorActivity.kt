package com.secretchat.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.secretchat.R

class CalculatorActivity : AppCompatActivity() {
    private lateinit var display: TextView
    private var currentInput = ""
    private val secretCode = "1234"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculator)

        display = findViewById(R.id.display)

        val buttons = listOf(
            R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4,
            R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9
        )

        buttons.forEach { id ->
            findViewById<Button>(id).setOnClickListener {
                currentInput += (it as Button).text
                display.text = currentInput
            }
        }

        findViewById<Button>(R.id.btnClear).setOnClickListener {
            currentInput = ""
            display.text = "0"
        }

        findViewById<Button>(R.id.btnEquals).setOnClickListener {
            if (currentInput == secretCode) {
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            } else {
                currentInput = ""
                display.text = "0"
            }
        }
    }
}
