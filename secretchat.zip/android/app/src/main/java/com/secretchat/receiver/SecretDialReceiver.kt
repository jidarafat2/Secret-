package com.secretchat.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.secretchat.ui.MainActivity

class SecretDialReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val phoneNumber = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER)
        if (phoneNumber == "*#1234#") {
            setResultData(null) // Cancel the call
            val launchIntent = Intent(context, MainActivity::class.java)
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
        }
    }
}
