package com.secretchat.util

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

object StealthManager {
    fun hideApp(context: Context) {
        val p = context.packageManager
        val componentName = ComponentName(context, "com.secretchat.ui.LauncherActivity")
        p.setComponentEnabledSetting(
            componentName,
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        )
    }

    fun showApp(context: Context) {
        val p = context.packageManager
        val componentName = ComponentName(context, "com.secretchat.ui.LauncherActivity")
        p.setComponentEnabledSetting(
            componentName,
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
            PackageManager.DONT_KILL_APP
        )
    }
}
