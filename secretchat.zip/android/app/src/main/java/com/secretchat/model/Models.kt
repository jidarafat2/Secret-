package com.secretchat.model

data class User(
    val uid: String = "",
    val username: String = "",
    val userId: String = "",
    val activeMode: Boolean = true,
    val lastSeen: Long = 0,
    val fcmToken: String = ""
)

data class Chat(
    val chatId: String = "",
    val participants: List<String> = emptyList(),
    val lastMessage: String = "",
    val lastTimestamp: Long = 0
)

data class Message(
    val id: String = "",
    val senderId: String = "",
    val text: String = "",
    val timestamp: Long = 0,
    val status: String = "sent",
    val autoDelete: Boolean = false
)
